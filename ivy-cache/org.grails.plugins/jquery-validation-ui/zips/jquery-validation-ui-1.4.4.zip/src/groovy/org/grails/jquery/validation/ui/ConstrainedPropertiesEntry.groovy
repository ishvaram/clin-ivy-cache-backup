package org.grails.jquery.validation.ui

class ConstrainedPropertiesEntry {
	String namespace
	Class validatableClass
	Map constrainedProperties
}
